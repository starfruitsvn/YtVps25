I went with WinRar as follows, this does not require you to create an sfx file, everything can be created via the gui:

Select files, right click and select Add to Archive
Use Browse.. to create the archive in the folder above
Change Archive Format to Zip
Enable Create SFX archive
Select Advanced tab
Select SFX Options
Select Setup tab
Enter setup.exe into the Run after Extraction field
Select Modes tab
Enable Unpack to temporary folder
Select text and Icon tab
Enter a more appropriate title for your task
Select OK
Select OK