const {google} = require('googleapis');
const fs = require('fs');
const path = require('path');
//const getMediaDimensions = require('get-media-dimensions');


//mau.tran@smad.com.vn
const CLIENT_ID = "328151558572-b0umhlp8nmmqqk7av3rjkunaoa7l6u2m.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const REDIRECT_URI = "https://developers.google.com/oauthplayground/";
const REFRESH_TOKEN = "1//04mFKNDsM_dGECgYIARAAGAQSNwF-L9IrmxYNzVUiiRjtygV4lRuLj6uXCg0LtGl99HV6ElHgihLATHpvZf763EZDKwg4vg841o8";


/*
//vntouch01
const CLIENT_ID = "137233300314-g42qv7lf5bh15uvilja34atsk0kivgnm.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const REDIRECT_URI = "https://developers.google.com/oauthplayground/";
const REFRESH_TOKEN = "1//04sX0hmETqetHCgYIARAAGAQSNwF-L9IrFtFe2yxP7nnlsaMl_1SEgr3LuNEIUD92YGklP9Qehkqts9tYNUyo9iCi-BF5ohEfqtw";
*/
/*
//convoi83@gmail.com
const CLIENT_ID = "123345041518-3qr18ni4oh1mtmu8btf3cbc3vlpanrsg.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const REDIRECT_URI = "https://developers.google.com/oauthplayground/";
const REFRESH_TOKEN = "1//04WVtRZj732NfCgYIARAAGAQSNwF-L9IrKr9Y3kntbSFwWe8i622yYizKIFMPjmsT8q1DW6U7zFNkbgY7hFVYee_6Ryj8k1_99ko";
*/

/*
//aduc25333@gmail.com
const CLIENT_ID = "144368069193-pet4p0uu4tdo56gv71ltj710k7pu9vjm.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const REDIRECT_URI = "https://developers.google.com/oauthplayground/";
const REFRESH_TOKEN = "1//04g3lviTWUhbCCgYIARAAGAQSNwF-L9Irfj_tQYpe2uKbRz-59__YJ4fuLdmz6-8lQeGybI58sxaQSljnehMgfPNOISj1WkQU7Jo";
*/

const oauth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URI);
oauth2Client.setCredentials({refresh_token: REFRESH_TOKEN});

const drive = google.drive({
    version: 'v3',
    auth: oauth2Client
})
/*
process.argv.forEach(function (val, index, array) {
  console.log(index + ': ' + val);
});
*/

var txtFile = process.argv[2];
console.log('txtFile = '+txtFile);
// Call start
(async() => {
  console.log('before start');

  await startUploadTxt();
  
  console.log('after start');
})();

async function startUploadTxt() {
  try {
    console.log("1")
    const createFile = await drive.files.create({
        requestBody: {
            name: txtFile+".txt",
            mimeType: 'text/plain'
        },
        media: {
            mimeType: 'text/plain',
            //body: fs.createReadStream(path.join(__dirname, 'C:\Users\Admin\AppData\Roaming\BrowserAutomationStudio\apps\25.3.5\11-15_T14-40-30.png'))
            body: fs.createReadStream('/home/proxy-installer'+txtFile+'.txt')
        }
    })
    console.log("2")
    const fileId = createFile.data.id;
    console.log(createFile.data)
    const getUrl = await that.setFilePublic(fileId);

    console.log(getUrl.data);

	} catch (error) {
		console.error(error);
	}
}
/*
var folderArray = [];
await searchAllFolder();
await Mp3Count();
async function Mp3Count()
{
    console.log('1 folderArray len = '+folderArray.length); 
    for (const folder of folderArray) {
        //console.log('Found file:', file.name, file.id);
        //console.log('Found file:');
        console.log('1 folder name = '+folder.name);
        console.log('1 folder id = '+folder.id);
        //console.log('1 folder ');
        //console.log(folder); 
        //const listFile = await listFiles(folder.id);
    }
}
*/
//await listFiles('1WsL96IVqRGK_e-wWSzf6UwFyrBRGH7pH','');

//await listAllFile('10eMmE4OMOGb2qI0vv668Wb3tY1gV-jMj'); //< 1000
//await listAllFile('1LCu-t5sbaG4uf53-RvYqqcas1vNEFWbY'); // > 1000
//await searchAllMp3();
async function searchAllFolder() {
  
  try {
    const res = await drive.files.list({
      q: 'mimeType = \'application/vnd.google-apps.folder\'',
      fields: 'nextPageToken, files(id, name)',
      spaces: 'drive',
    });
    //Array.prototype.push.apply(folderArray, res.files);
    
    res.data.files.forEach(function(file) {
      //console.log('Found file:', file.name, file.id);
      //console.log('Found file:');
      console.log('folder name = '+file.name);
      console.log('folder id = '+file.id);
      folderArray.push(file);
    });
    console.log('folderArray len = '+folderArray.length); 
  } catch (err) {
    // TODO(developer) - Handle error
    throw err;
  }
}


async function searchFolder() {
  const files = [];
  try {
    const res = await drive.files.list({
      q: 'mimeType = \'application/vnd.google-apps.folder\'',
      fields: 'nextPageToken, files(id, name)',
      spaces: 'drive',
    });
    Array.prototype.push.apply(files, res.files);
    console.log('folderName = '+folderName);
    res.data.files.forEach(function(file) {
      //console.log('Found file:', file.name, file.id);
      //console.log('Found file:');
      console.log('folder name = '+file.name);
      console.log('index = '+file.name.indexOf(folderName));
      if (file.name.indexOf(folderName) > -1)
      {
          console.log('da co folder');
          folderId = file.id;
          return folderId;
      }
    });
    //return res.data.files;
    return folderId;
  } catch (err) {
    // TODO(developer) - Handle error
    throw err;
  }
}

async function searchAllMp3() {
  const files = [];
  try {
    const res = await drive.files.list({
      q: 'mimeType=\'audio/mp3\'',
      fields: 'nextPageToken, files(id, name)',
      pageSize: '1000',
      spaces: 'drive',
    });
    console.log('file count = '+res.data.files.length);
  } catch (err) {
    // TODO(developer) - Handle error
    throw err;
  }
}
/*
function listFiles(auth) {
  const drive = google.drive({version: 'v3', auth});
  drive.files.list({
    q: 'name = "NAMEHERE" and parents in "FOLDERID"',
    pageSize: 10,
    fields: 'nextPageToken, files(id, name, webViewLink)',
  }, (err, res) => {
    if (err) return console.log('The API returned an error: ' + err);
    const files = res.data.files;
    if (files.length) {
      console.log('Files:');
      files.map((file) => {
        console.log(`${file.name} ${file.webViewLink}`);
      });
    } else {
      console.log('No files found.');
    }
  });
}
*/
async function listAllFile(folderId)
{
    var nextTk = '';
    var fileLen = 0;
    var totalLen = 0;
    try {
        var res = await drive.files.list({
            q: `'${folderId}' in parents`,
            fields: 'nextPageToken, files(id, name)',
            pageSize: '1000',
            //pageToken: `'${pageTk}'`,
            });
        console.log('file count = '+res.data.files.length);
        fileLen = res.data.files.length;
        totalLen += fileLen;
        nextTk = res.data.nextPageToken;
        
    } catch (err) {
        // TODO(developer) - Handle error
        throw err;
    }
    res = null;
    while (fileLen == 1000)
    {
        console.log('nextTk = '+nextTk);
        try {
            res = await drive.files.list({
                q: `'${folderId}' in parents`,
                fields: 'nextPageToken, files(id, name)',
                pageSize: '1000',
                //pageToken: `'${nextTk}'`,
                pageToken: nextTk,
                });
            console.log('file count = '+res.data.files.length);
            fileLen = res.data.files.length;
            totalLen += fileLen;
            nextTk = res.data.nextPageToken;
            //console.log('nextTk = '+nextTk);
        } catch (err) {
            // TODO(developer) - Handle error
            console.log('err = '+err);
            throw err;
        }
        res = null;
    }
    console.log('totalLen  = '+totalLen);
}
async function listFiles(folderId,pageTk) {
    //const folderId = '1uCd0bUfpqzCsR2wGyKxBG_KJfIbTBsus'; // Thay thế 'folder-id-here' bằng id của thư mục bạn muốn liệt kê.
    try {
        const res = await drive.files.list({
            q: `'${folderId}' in parents`,
            fields: 'nextPageToken, files(id, name)',
            pageSize: '1000',
            //pageToken: `'${pageTk}'`,
            });
        console.log('file count = '+res.data.files.length);
    } catch (err) {
        // TODO(developer) - Handle error
        throw err;
    }
}
async function searchFile() {
  const files = [];
  try {
    const res = await drive.files.list({
      q: 'mimeType=\'image/jpeg\'',
      fields: 'nextPageToken, files(id, name)',
      spaces: 'drive',
    });
    Array.prototype.push.apply(files, res.files);
    res.data.files.forEach(function(file) {
      console.log('Found file:', file.name, file.id);
    });
    return res.data.files;
  } catch (err) {
    // TODO(developer) - Handle error
    throw err;
  }
}
async function createfolder()
{
    const fileMetaData = {
    name: folderName,
    mimeType: "application/vnd.google-apps.folder",
  };
  const res = await drive.files
    .create({
      fields: "id",
      resource: fileMetaData,
    })
    .catch((err) => console.log(err));
    [[FOLDER_ID]] = res.data.id;
  console.log('res.data = ');
  console.log(res.data);
  return res.data.id;
}
async function start(fdId) {
  try {
    console.log("1")
    console.log("fdId = "+fdId)

    const fileMetaData = {
        name: file+".mp3",
        parents: [fdId],
        mimeType: 'audio/mp3'
    }

    const media = {
        mimeType: 'audio/mp3',
        body: fs.createReadStream([[NEW_FILE_NAME]])
    }

    const createFile = await drive.files.create({
        requestBody: fileMetaData,
        media: media
    })
    /*
    const createFile = await drive.files.create({
        requestBody: {
            name: file+".mp3",
            mimeType: 'audio/mp3',
            parents: fdId
        },
        media: {
            mimeType: 'audio/mp3',
            //body: fs.createReadStream(path.join(__dirname, 'C:\Users\Admin\AppData\Roaming\BrowserAutomationStudio\apps\25.3.5\11-15_T14-40-30.png'))
            body: fs.createReadStream('/home/proxy-installer')
        }
    })
    */
    console.log("2")
    const fileId = createFile.data.id;
    console.log(createFile.data)
    const getUrl = await that.setFilePublic(fileId);

    console.log(getUrl.data);

	} catch (error) {
		console.error(error);
	}
}

async function startTxt() {
  try {
    console.log("1")
    const createFile = await drive.files.create({
        requestBody: {
            name: [[USERNAME]]+".txt",
            mimeType: 'text/plain'
        },
        media: {
            mimeType: 'text/plain',
            //body: fs.createReadStream(path.join(__dirname, 'C:\Users\Admin\AppData\Roaming\BrowserAutomationStudio\apps\25.3.5\11-15_T14-40-30.png'))
            body: fs.createReadStream([[STORE_FILE]])
        }
    })
    console.log("2")
    const fileId = createFile.data.id;
    console.log(createFile.data)
    const getUrl = await that.setFilePublic(fileId);

    console.log(getUrl.data);

	} catch (error) {
		console.error(error);
	}
}
var that = module.exports = {
    setFilePublic: async(fileId) =>{
        try {
            await drive.permissions.create({
                fileId,
                requestBody: {
                    role: 'reader',
                    type: 'anyone'
                }
            })

            const getUrl = await drive.files.get({
                fileId,
                fields: 'webViewLink, webContentLink'
            })

            return getUrl;
        } catch (error) {
            console.error(error);
        }
    },
    uploadFile: async ({shared}) => {
        try {
            const createFile = await drive.files.create({
                requestBody: {
                    name: "C:\Users\Admin\AppData\Roaming\BrowserAutomationStudio\apps\25.3.5\11-15_T14-40-30.png",
                    mimeType: 'image/jpg'
                },
                media: {
                    mimeType: 'image/jpg',
                    body: fs.createReadStream(path.join(__dirname, '/../cr7.jpg'))
                }
            })
            const fileId = createFile.data.id;
            console.log(createFile.data)
            const getUrl = await that.setFilePublic(fileId);

            console.log(getUrl.data);

        } catch (error) {
            console.error(error);
        }
    },
    deleteFile: async (fileId) => {
        try {
            console.log('Delete File:::', fileId);
            const deleteFile = await drive.files.delete({
                fileId: fileId
            })
            console.log(deleteFile.data, deleteFile.status)
        } catch (error) {
            console.error(error);
        }
    }
}